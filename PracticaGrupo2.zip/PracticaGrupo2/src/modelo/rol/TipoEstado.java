
package modelo.rol;


public enum TipoEstado {
    DIVORCIADA, DIVORCIADO, SEPARADA, SEPARADO;
}
