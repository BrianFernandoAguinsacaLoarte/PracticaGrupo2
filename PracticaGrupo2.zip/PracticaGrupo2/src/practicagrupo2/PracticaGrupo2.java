/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practicagrupo2;

import vista.listas.Menu;

/**
 *
 * @author Desarrollado por Brian Aguinsaca - 3B
 */
public class PracticaGrupo2 {

    
    public static void main(String[] args) {
        //Funcionamiento ventana Detalle
        Menu menu = new Menu();
        menu.setVisible(true);
        
    }
    
}
